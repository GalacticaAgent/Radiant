import { useEffect, useState } from 'react'
import { Modal, App, Spin, Alert, Card, Empty, Tag, List } from 'antd'
import { FileSearchOutlined } from '@ant-design/icons'
import MarkdownRenderer from '../Common/MarkdownRenderer'
import { paperAPI } from '../../api/paper'

interface FormatReviewModalProps {
  open: boolean
  paperId: string | null
  file: File | null
  text: string | null
  inserted: boolean
  onInserted: () => void
  onClose: () => void
  onAppendToChat: (content: string) => void
}

const stripJsonFences = (md: string) => md.replace(/```\s*json[\s\S]*?```/gi, '').trim()

export default function FormatReviewModal({
  open,
  paperId,
  file,
  text,
  inserted,
  onInserted,
  onClose,
  onAppendToChat,
}: FormatReviewModalProps) {
  const { message } = App.useApp()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [markdown, setMarkdown] = useState<string | null>(null)
  const [ruleIssues, setRuleIssues] = useState<any[] | null>(null)
  const [llmIssues, setLlmIssues] = useState<any[] | null>(null)
  const [autoMetrics, setAutoMetrics] = useState<Record<string, any> | null>(null)

  const generate = async () => {
    try {
      const contentText = (text || '').trim()

      if (!paperId && !file && !contentText) {
        setError('请先在输入框中输入文本或选择 PDF/DOCX 文件后再点击“格式审查”。')
        return
      }

      setLoading(true)
      setError(null)
      let md = ''
      let ri: any[] | null = null
      let li: any[] | null = null
      let am: Record<string, any> | null = null
      if (file || contentText) {
        const fd = new FormData()
        if (file) fd.append('file', file)
        if (contentText) fd.append('text', contentText)
        fd.append('scope', 'auto')
        const res = await paperAPI.formatReviewAdhoc(fd)
        md = res.markdown || ''
        ri = (res as any).rule_issues || null
        li = (res as any).llm_issues || null
        am = (res as any).auto_metrics || null
      } else if (paperId) {
        const res = await paperAPI.formatReview(paperId, 'auto')
        md = res.markdown || ''
        ri = (res as any).rule_issues || null
        li = (res as any).llm_issues || null
        am = (res as any).auto_metrics || null
      }

      const cleaned = stripJsonFences(md)
      setMarkdown(cleaned)
      setRuleIssues(Array.isArray(ri) ? ri : null)
      setLlmIssues(Array.isArray(li) ? li : null)
      setAutoMetrics(am && typeof am === 'object' ? am : null)
      message.success('已生成格式审查报告')
    } catch (e: any) {
      setError(e?.response?.data?.detail || e?.message || '生成格式审查失败')
      message.error(e?.response?.data?.detail || e?.message || '生成格式审查失败')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (!open) {
      setLoading(false)
      setError(null)
      setMarkdown(null)
      setRuleIssues(null)
      setLlmIssues(null)
      setAutoMetrics(null)
      return
    }
    if (markdown) return
    if (loading) return
    generate()
  }, [open])

  useEffect(() => {
    if (!open) return
    if (!markdown) return
    if (inserted) return
    onAppendToChat(markdown.trim() + '\n')
    onInserted()
  }, [open, markdown, inserted])

  const renderIssue = (it: any) => {
    const sev = String(it?.severity || '').toLowerCase()
    const color = sev === 'critical' ? 'red' : sev === 'major' ? 'orange' : sev === 'minor' ? 'blue' : 'default'
    const position = String(it?.position || '').trim()
    const description = String(it?.description || '').trim()
    const suggestion = String(it?.suggestion || '').trim()
    const evidence = String(it?.evidence || '').trim()
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <Tag color={color}>{sev || 'minor'}</Tag>
          <div style={{ fontWeight: 700 }}>{position || '未标注位置'}</div>
        </div>
        <div style={{ color: 'rgba(30, 41, 59, 0.85)' }}>{description}</div>
        {suggestion ? <div style={{ color: 'rgba(30, 41, 59, 0.7)' }}>建议：{suggestion}</div> : null}
        {evidence ? <div style={{ color: 'rgba(30, 41, 59, 0.55)' }}>证据：{evidence}</div> : null}
      </div>
    )
  }

  return (
    <Modal open={open} onCancel={onClose} footer={null} centered width={860} destroyOnHidden>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <FileSearchOutlined />
            <h2 style={{ margin: 0 }}>格式审查</h2>
          </div>
        </div>
      </div>

      <div style={{ marginTop: 12 }}>
        {error ? <Alert type="warning" showIcon message={error} /> : null}
      </div>

      <Card style={{ marginTop: 12 }}>
        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: 24 }}>
            <Spin />
          </div>
        ) : markdown ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {ruleIssues?.length ? (
              <Card size="small" title="硬规则检查（规则引擎）">
                <List
                  dataSource={ruleIssues}
                  renderItem={(it, idx) => <List.Item key={String(it?.position || idx)}>{renderIssue(it)}</List.Item>}
                />
              </Card>
            ) : null}

            {llmIssues?.length ? (
              <Card size="small" title="AI 补充问题（LLM）">
                <List
                  dataSource={llmIssues}
                  renderItem={(it, idx) => <List.Item key={String(it?.position || idx)}>{renderIssue(it)}</List.Item>}
                />
              </Card>
            ) : null}

            {autoMetrics ? (
              <Card size="small" title="自动检测摘要">
                <pre style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{JSON.stringify(autoMetrics, null, 2)}</pre>
              </Card>
            ) : null}

            <Card size="small" title="审查报告（可插入聊天）">
              <MarkdownRenderer content={markdown} />
            </Card>
          </div>
        ) : (
          <Empty description="暂无格式审查结果" />
        )}
      </Card>
    </Modal>
  )
}
